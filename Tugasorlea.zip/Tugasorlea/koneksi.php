<?php 

 $conn = pg_connect("host='localhost' user='postgres' password='ipankz123' dbname='db_toko'");

 ?>